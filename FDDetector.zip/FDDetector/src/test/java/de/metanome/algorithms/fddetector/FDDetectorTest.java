package de.metanome.algorithms.fddetector;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FDDetectorTest {

  @Before
  public void setUp() throws Exception {
  }

  @After
  public void tearDown() throws Exception {
  }

  @Test
  public void testGetConfigurationRequirements() {
  }

  @Test
  public void testExecute() {
	  System.out.println("test");
  }

  @Test
  public void testSetConfigurationValue() {
  }

  @Test
  public void testSetTempFileGenerator() {
  }

  @Test
  public void testSetResultReceiverFunctionalDependencyResultReceiver() {
  }

  @Test
  public void testSetResultReceiverUniqueColumnCombinationResultReceiver() {
  }

}
